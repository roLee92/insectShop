/* Select customers where the customerid is equal to a passed customer id */
SELECT *
FROM Customers
WHERE customerid = :customerid