DELETE FROM book_categories
WHERE isbn = :isbn