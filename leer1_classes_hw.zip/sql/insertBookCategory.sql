INSERT INTO book_categories (isbn, categoryid)
VALUES(:isbn, :categoryid);
