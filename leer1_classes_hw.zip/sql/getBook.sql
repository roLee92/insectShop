SELECT *
FROM books
WHERE isbn = :isbn