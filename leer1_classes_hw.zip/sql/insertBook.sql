INSERT INTO books (isbn, title, author, price)
VALUES(:isbn, :title, :author, :price)
