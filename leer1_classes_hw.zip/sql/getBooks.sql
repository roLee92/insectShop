SELECT *
FROM Books
WHERE title LIKE :term