SELECT categoryid, name
FROM categories