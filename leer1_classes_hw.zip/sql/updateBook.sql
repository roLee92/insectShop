UPDATE books
SET isbn = :isbn, author = :author, price = :price, title = :title
WHERE isbn = :isbn