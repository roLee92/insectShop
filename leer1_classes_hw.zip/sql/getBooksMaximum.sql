SELECT * 
FROM books 
WHERE price <= :maximum_price